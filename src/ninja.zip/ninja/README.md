<img align=right width=500 src="http://www.pentaho.com/sites/default/files/14-067-pentaho-ninja-campaign-v12.jpg">


# Ninja tricks for Data Science


## INSTALL


1. Download https://goo.gl/rNmPcV (is a zip file)
2. unzip that zip file
3. cd ninja
4. sh ninja

## USAGE

```bash
Here=$(pwd) bash --init-file ninja.rc -i
```

TIP: place the above line into a file `ninja` and call with:

```bash
$ sh ninja
```
