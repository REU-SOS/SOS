# References

## D

+ <a name=Do95>Do95</a>:
      + Dougherty, James, Ron Kohavi, and Mehran Sahami.
        ["Supervised and unsupervised discretization of continuous
        features."](http://www.math.unipd.it/~dulli/corso04/disc.pdf) Machine
        learning: proceedings of the twelfth international
        conference. Vol. 12. 1995.

## F

+ <a name=Fa93>Fa93</a>
       + Fayyad, Usama M.; Irani, Keki B. (1993) ["Multi-Interval
         Discretization of Continuous-Valued Attributes for Classification
         Learning"](http://trs-new.jpl.nasa.gov/dspace/bitstream/2014/35171/1/93-0738.pdf),
         Proceedings of the International Joint Conference on Uncertainty in AI  pp. 1022-1027
