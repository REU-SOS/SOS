# Maths of Data Mining

T.B.D.

Curse (=blessing) of dimensionality.

VOlume N-th dimensional sphere

k = sqrt (sum (diffs))

low dimensional manifolds

random projects

spectral clsutering